import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.css";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";
import axios from 'axios';
import "./app.scss";
import Search from './search';

const columns = [
  {
    dataField: "paymentAmount",
    text: "Payment Amount"
  },
  {
    dataField: "paymentCurrency",
    text: "Payment Currency"
  },
  {
    dataField: "paymentDate",
    text: "Payment Date"
  },
  {
    dataField: "paymentStatus",
    text: "Payment Status"
  },
  {
    dataField: "paymentType",
    text: "Payment Type"
  }
];

const App = () => {

  const [response, setResponse] = useState([]);
  const [searchData, setSearchData] = useState([]);
  const [searchResult, setSearchResult] = useState(false);
  const [errorMessage, setErrorMessage] = useState(true);

  useEffect(() => {
    axios.get(`http://localhost:9001/api/payments`)
      .then(res => {
        if(res.data){
          setResponse(res.data.results);
          setErrorMessage(false);
        }
      })
  }, []);

  const handleSetData = (val) => {
    if (val.length > 0) {
      setSearchData(val);
      setSearchResult(true);
      setErrorMessage(false);
    }else{
      setErrorMessage(true);
    }
  }

  const loadData = searchResult ? searchData : response;

  return (
    <div className="App">
      <br />
      <h1>React-Assignment</h1>
      <br />
      <Search data={response} handleSetData={handleSetData} />
      <div>{errorMessage ? <div className="errorMessage">No Result Found.</div> :
        <BootstrapTable
          bootstrap4
          keyField="id"
          data={loadData}
          columns={columns}
          pagination={paginationFactory({ sizePerPage: 5 })}
        />
      }</div>
    </div>
  );
}

export default App;
