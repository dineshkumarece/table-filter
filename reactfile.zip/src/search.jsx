import React from "react";

export default class DropDownComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            searchInput: ""
        };
    }

    handleChange = event => {
        this.setState({ searchInput: event.target.value }, () =>
            this.globalSearch()
        );
    };

    globalSearch = () => {
        let { searchInput } = this.state;
        let filteredData = this.props.data.filter(value => {
            return (
                value.paymentStatus.toLowerCase().includes(searchInput.toLowerCase())
            );
        });
        this.props.handleSetData(filteredData);
    };

    render() {
        return (
            <>
                <br />
                <h5>Search: &nbsp;
                    <input
                        size="large"
                        name="searchInput"
                        placeholder="Enter Value"
                        value={this.state.searchInput || ""}
                        onChange={this.handleChange}
                        label="Search"
                    />
                </h5>
                <br />
                <br />
            </>
        );
    }
}
